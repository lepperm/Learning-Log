# Your Favicon Package

This package was generated with [RealFaviconGenerator](https://realfavicongenerator.net/) [v0.16](https://realfavicongenerator.net/change_log#v0.16)

## Install instructions

To install this package:

Extract this package in <code>&lt;web site&gt;/learning-log/assets/images/favicons/</code>. If your site is <code>http://www.example.com</code>, you should be able to access a file named <code>http://www.example.com/learning-log/assets/images/favicons/favicon.ico</code>.

Insert the following code in the `head` section of your pages:

    <link rel="apple-touch-icon" sizes="180x180" href="/learning-log/assets/images/favicons/apple-touch-icon.png?v=jw37AePQw4">
    <link rel="icon" type="image/png" sizes="32x32" href="/learning-log/assets/images/favicons/favicon-32x32.png?v=jw37AePQw4">
    <link rel="icon" type="image/png" sizes="194x194" href="/learning-log/assets/images/favicons/favicon-194x194.png?v=jw37AePQw4">
    <link rel="icon" type="image/png" sizes="192x192" href="/learning-log/assets/images/favicons/android-chrome-192x192.png?v=jw37AePQw4">
    <link rel="icon" type="image/png" sizes="16x16" href="/learning-log/assets/images/favicons/favicon-16x16.png?v=jw37AePQw4">
    <link rel="manifest" href="/learning-log/assets/images/favicons/site.webmanifest?v=jw37AePQw4">
    <link rel="mask-icon" href="/learning-log/assets/images/favicons/safari-pinned-tab.svg?v=jw37AePQw4" color="#27455d">
    <link rel="shortcut icon" href="/learning-log/assets/images/favicons/favicon.ico?v=jw37AePQw4">
    <meta name="apple-mobile-web-app-title" content="Learning Log">
    <meta name="application-name" content="Learning Log">
    <meta name="msapplication-TileColor" content="#27455d">
    <meta name="msapplication-TileImage" content="/learning-log/assets/images/favicons/mstile-144x144.png?v=jw37AePQw4">
    <meta name="msapplication-config" content="/learning-log/assets/images/favicons/browserconfig.xml?v=jw37AePQw4">
    <meta name="theme-color" content="#98d9e4">

*Optional* - Check your favicon with the [favicon checker](https://realfavicongenerator.net/favicon_checker)